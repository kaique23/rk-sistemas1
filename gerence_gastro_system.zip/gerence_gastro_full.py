
from __future__ import annotations

from datetime import datetime, timedelta
from enum import Enum
from typing import Optional, List

from fastapi import FastAPI, Depends, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr
from sqlalchemy import create_engine, Column, Integer, String, DateTime, ForeignKey, Float, Text, Boolean
from sqlalchemy.orm import declarative_base, sessionmaker, Session
import bcrypt
import jwt

DATABASE_URL = "sqlite:///./gerence_gastro.db"
SECRET_KEY = "gerence-sistemas-chave-troque-em-producao"
ALGORITHM = "HS256"
TOKEN_EXPIRE_HOURS = 12

DEFAULT_ADMIN_EMAIL = "admin@gerence.local"
DEFAULT_ADMIN_PASSWORD = "Admin@123"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

app = FastAPI(title="Gerence Sistemas - Gastronomia", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Role(str, Enum):
    admin_geral = "admin_geral"
    admin_empresa = "admin_empresa"
    gerente = "gerente"
    caixa = "caixa"
    garcom = "garcom"
    cozinha = "cozinha"

class OrderStatus(str, Enum):
    aberto = "aberto"
    preparando = "preparando"
    pronto = "pronto"
    entregue = "entregue"

class TableStatus(str, Enum):
    livre = "livre"
    ocupada = "ocupada"

class AdminGeral(Base):
    __tablename__ = "admins_gerais"
    id = Column(Integer, primary_key=True)
    nome = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    senha_hash = Column(String, nullable=False)
    criado_em = Column(DateTime, default=datetime.utcnow)

class Empresa(Base):
    __tablename__ = "empresas"
    id = Column(Integer, primary_key=True)
    nome_fantasia = Column(String, nullable=False)
    razao_social = Column(String)
    cnpj = Column(String, unique=True, index=True, nullable=False)
    telefone = Column(String)
    email = Column(String)
    endereco = Column(String)
    pix_chave = Column(String)
    pix_nome = Column(String)
    pix_cidade = Column(String, default="MARINGA")
    criado_em = Column(DateTime, default=datetime.utcnow)

class Usuario(Base):
    __tablename__ = "usuarios"
    id = Column(Integer, primary_key=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id"), index=True)
    nome = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    senha_hash = Column(String, nullable=False)
    papel = Column(String, default=Role.caixa.value)
    ativo = Column(Boolean, default=True)
    criado_em = Column(DateTime, default=datetime.utcnow)

class Cliente(Base):
    __tablename__ = "clientes"
    id = Column(Integer, primary_key=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id"), index=True)
    nome = Column(String, nullable=False)
    telefone = Column(String)
    email = Column(String)
    documento = Column(String)
    endereco = Column(String)
    observacoes = Column(Text)

class Fornecedor(Base):
    __tablename__ = "fornecedores"
    id = Column(Integer, primary_key=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id"), index=True)
    nome = Column(String, nullable=False)
    telefone = Column(String)
    email = Column(String)
    documento = Column(String)
    endereco = Column(String)

class Funcionario(Base):
    __tablename__ = "funcionarios"
    id = Column(Integer, primary_key=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id"), index=True)
    nome = Column(String, nullable=False)
    cargo = Column(String)
    telefone = Column(String)
    email = Column(String)
    comissao_percentual = Column(Float, default=0)

class Produto(Base):
    __tablename__ = "produtos"
    id = Column(Integer, primary_key=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id"), index=True)
    codigo = Column(String, index=True)
    nome = Column(String, nullable=False)
    categoria = Column(String)
    preco = Column(Float, nullable=False)
    custo = Column(Float, default=0)
    estoque = Column(Float, default=0)
    estoque_minimo = Column(Float, default=0)
    unidade = Column(String, default="UN")
    e_kg = Column(Boolean, default=False)
    ativo = Column(Boolean, default=True)

class FichaTecnica(Base):
    __tablename__ = "fichas_tecnicas"
    id = Column(Integer, primary_key=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id"), index=True)
    produto_id = Column(Integer, ForeignKey("produtos.id"), index=True)
    ingrediente_id = Column(Integer, ForeignKey("produtos.id"), index=True)
    quantidade = Column(Float, default=0)
    custo_total = Column(Float, default=0)

class Mesa(Base):
    __tablename__ = "mesas"
    id = Column(Integer, primary_key=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id"), index=True)
    numero = Column(String, nullable=False)
    status = Column(String, default=TableStatus.livre.value)
    cliente_nome = Column(String)
    total = Column(Float, default=0)
    pix_code = Column(Text)

class Comanda(Base):
    __tablename__ = "comandas"
    id = Column(Integer, primary_key=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id"), index=True)
    mesa_id = Column(Integer, ForeignKey("mesas.id"), index=True, nullable=True)
    cliente_nome = Column(String)
    garcom_nome = Column(String)
    aberta = Column(Boolean, default=True)
    total = Column(Float, default=0)
    criada_em = Column(DateTime, default=datetime.utcnow)

class Pedido(Base):
    __tablename__ = "pedidos"
    id = Column(Integer, primary_key=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id"), index=True)
    comanda_id = Column(Integer, ForeignKey("comandas.id"), index=True, nullable=True)
    mesa_id = Column(Integer, ForeignKey("mesas.id"), index=True, nullable=True)
    origem = Column(String, default="PDV")
    status = Column(String, default=OrderStatus.aberto.value)
    setor = Column(String, default="COZINHA")
    cliente_nome = Column(String)
    observacoes = Column(Text)
    tempo_estimado_min = Column(Integer, default=20)
    criado_em = Column(DateTime, default=datetime.utcnow)
    entregue_em = Column(DateTime, nullable=True)

class PedidoItem(Base):
    __tablename__ = "pedido_itens"
    id = Column(Integer, primary_key=True)
    pedido_id = Column(Integer, ForeignKey("pedidos.id"), index=True)
    produto_id = Column(Integer, ForeignKey("produtos.id"), index=True)
    nome = Column(String, nullable=False)
    quantidade = Column(Float, default=1)
    preco_unitario = Column(Float, default=0)
    subtotal = Column(Float, default=0)
    observacoes = Column(Text)

class CaixaMovimento(Base):
    __tablename__ = "caixa_movimentos"
    id = Column(Integer, primary_key=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id"), index=True)
    tipo = Column(String, nullable=False)
    descricao = Column(String)
    valor = Column(Float, default=0)
    usuario_nome = Column(String)
    criado_em = Column(DateTime, default=datetime.utcnow)

class Financeiro(Base):
    __tablename__ = "financeiro"
    id = Column(Integer, primary_key=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id"), index=True)
    tipo = Column(String, nullable=False)
    descricao = Column(String, nullable=False)
    categoria = Column(String)
    valor = Column(Float, default=0)
    pago = Column(Boolean, default=False)
    vencimento = Column(DateTime, nullable=True)
    criado_em = Column(DateTime, default=datetime.utcnow)

class Delivery(Base):
    __tablename__ = "deliveries"
    id = Column(Integer, primary_key=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id"), index=True)
    pedido_id = Column(Integer, ForeignKey("pedidos.id"), index=True)
    cliente_nome = Column(String)
    endereco = Column(String)
    entregador = Column(String)
    status = Column(String, default="aguardando")
    rota = Column(Text)

class Integracao(Base):
    __tablename__ = "integracoes"
    id = Column(Integer, primary_key=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id"), index=True)
    tipo = Column(String, nullable=False)
    ativo = Column(Boolean, default=False)
    dados_json = Column(Text, default="{}")

Base.metadata.create_all(bind=engine)

class LoginSchema(BaseModel):
    email: EmailStr
    senha: str

class EmpresaCreate(BaseModel):
    nome_fantasia: str
    razao_social: Optional[str] = None
    cnpj: str
    telefone: Optional[str] = None
    email: Optional[str] = None
    endereco: Optional[str] = None
    pix_chave: Optional[str] = None
    pix_nome: Optional[str] = None
    pix_cidade: Optional[str] = "MARINGA"
    admin_nome: str = "Administrador"
    admin_email: EmailStr
    admin_senha: str = "123456"

class UsuarioCreate(BaseModel):
    nome: str
    email: EmailStr
    senha: str
    papel: str = Role.caixa.value

class ProdutoCreate(BaseModel):
    codigo: str
    nome: str
    categoria: Optional[str] = None
    preco: float
    custo: float = 0
    estoque: float = 0
    estoque_minimo: float = 0
    unidade: str = "UN"
    e_kg: bool = False

class ClienteCreate(BaseModel):
    nome: str
    telefone: Optional[str] = None
    email: Optional[str] = None
    documento: Optional[str] = None
    endereco: Optional[str] = None
    observacoes: Optional[str] = None

class FornecedorCreate(BaseModel):
    nome: str
    telefone: Optional[str] = None
    email: Optional[str] = None
    documento: Optional[str] = None
    endereco: Optional[str] = None

class FuncionarioCreate(BaseModel):
    nome: str
    cargo: Optional[str] = None
    telefone: Optional[str] = None
    email: Optional[str] = None
    comissao_percentual: float = 0

class MesaCreate(BaseModel):
    numero: str
    cliente_nome: Optional[str] = None

class ComandaCreate(BaseModel):
    mesa_id: Optional[int] = None
    cliente_nome: Optional[str] = None
    garcom_nome: Optional[str] = None

class PedidoItemCreate(BaseModel):
    produto_id: int
    quantidade: float
    observacoes: Optional[str] = None

class PedidoCreate(BaseModel):
    comanda_id: Optional[int] = None
    mesa_id: Optional[int] = None
    origem: str = "PDV"
    setor: str = "COZINHA"
    cliente_nome: Optional[str] = None
    observacoes: Optional[str] = None
    tempo_estimado_min: int = 20
    itens: List[PedidoItemCreate]

class CaixaCreate(BaseModel):
    tipo: str
    descricao: Optional[str] = None
    valor: float = 0

class FinanceiroCreate(BaseModel):
    tipo: str
    descricao: str
    categoria: Optional[str] = None
    valor: float
    vencimento: Optional[datetime] = None

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def hash_senha(senha: str) -> str:
    return bcrypt.hashpw(senha[:72].encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

def verificar_senha(senha: str, senha_hash: str) -> bool:
    return bcrypt.checkpw(senha[:72].encode("utf-8"), senha_hash.encode("utf-8"))

def gerar_token(payload: dict) -> str:
    dados = payload.copy()
    dados["exp"] = datetime.utcnow() + timedelta(hours=TOKEN_EXPIRE_HOURS)
    return jwt.encode(dados, SECRET_KEY, algorithm=ALGORITHM)

def decodificar_token(token: str) -> dict:
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Token inválido ou expirado")

def get_token(authorization: Optional[str]) -> str:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Use Authorization: Bearer TOKEN")
    return authorization.replace("Bearer ", "").strip()

def get_admin(authorization: Optional[str] = Header(default=None), db: Session = Depends(get_db)):
    payload = decodificar_token(get_token(authorization))
    admin = db.query(AdminGeral).filter(AdminGeral.id == int(payload["sub"])).first()
    if not admin:
        raise HTTPException(status_code=401, detail="Admin não encontrado")
    return admin

def get_usuario(authorization: Optional[str] = Header(default=None), db: Session = Depends(get_db)):
    payload = decodificar_token(get_token(authorization))
    usuario = db.query(Usuario).filter(Usuario.id == int(payload["sub"])).first()
    if not usuario:
        raise HTTPException(status_code=401, detail="Usuário não encontrado")
    return usuario

def emv(ident: str, valor: str) -> str:
    valor = str(valor)
    return f"{ident}{len(valor):02d}{valor}"

def crc16_ccitt(payload: str) -> str:
    polinomio = 0x1021
    resultado = 0xFFFF
    for ch in payload:
        resultado ^= (ord(ch) << 8)
        for _ in range(8):
            if resultado & 0x8000:
                resultado = ((resultado << 1) ^ polinomio) & 0xFFFF
            else:
                resultado = (resultado << 1) & 0xFFFF
    return f"{resultado:04X}"

def gerar_payload_pix(chave: str, nome: str, cidade: str, valor: float) -> str:
    nome = (nome or "GERENCE SISTEMAS").upper()[:25]
    cidade = (cidade or "MARINGA").upper()[:15]
    payload = ""
    payload += emv("00", "01")
    payload += emv("01", "12")
    payload += emv("26", emv("00", "BR.GOV.BCB.PIX") + emv("01", chave))
    payload += emv("52", "0000")
    payload += emv("53", "986")
    payload += emv("54", f"{valor:.2f}")
    payload += emv("58", "BR")
    payload += emv("59", nome)
    payload += emv("60", cidade)
    payload += emv("62", emv("05", "***"))
    base = payload + "6304"
    return base + crc16_ccitt(base)

def empresa_pix(db: Session, empresa_id: int, total: float):
    empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
    if not empresa or not empresa.pix_chave:
        return None
    return gerar_payload_pix(empresa.pix_chave, empresa.pix_nome or empresa.nome_fantasia, empresa.pix_cidade or "MARINGA", total)

def seed_admin():
    db = SessionLocal()
    try:
        existe = db.query(AdminGeral).filter(AdminGeral.email == DEFAULT_ADMIN_EMAIL).first()
        if not existe:
            db.add(AdminGeral(nome="Administrador Gerence", email=DEFAULT_ADMIN_EMAIL, senha_hash=hash_senha(DEFAULT_ADMIN_PASSWORD)))
            db.commit()
    finally:
        db.close()

seed_admin()

@app.get("/")
def root():
    return {"ok": True, "sistema": "Gerence Sistemas - Gastronomia", "admin_padrao": {"email": DEFAULT_ADMIN_EMAIL, "senha": DEFAULT_ADMIN_PASSWORD}}

@app.post("/auth/admin/login")
def login_admin(data: LoginSchema, db: Session = Depends(get_db)):
    admin = db.query(AdminGeral).filter(AdminGeral.email == data.email.lower()).first()
    if not admin or not verificar_senha(data.senha, admin.senha_hash):
        raise HTTPException(status_code=401, detail="Email ou senha inválidos")
    token = gerar_token({"sub": str(admin.id), "tipo": Role.admin_geral.value, "email": admin.email})
    return {"access_token": token, "token_type": "bearer"}

@app.post("/auth/empresa/login")
def login_empresa(data: LoginSchema, db: Session = Depends(get_db)):
    usuario = db.query(Usuario).filter(Usuario.email == data.email.lower(), Usuario.ativo == True).first()
    if not usuario or not verificar_senha(data.senha, usuario.senha_hash):
        raise HTTPException(status_code=401, detail="Email ou senha inválidos")
    token = gerar_token({"sub": str(usuario.id), "tipo": "usuario_empresa", "empresa_id": usuario.empresa_id, "papel": usuario.papel, "email": usuario.email})
    return {"access_token": token, "token_type": "bearer"}

@app.post("/admin/empresas")
def criar_empresa(data: EmpresaCreate, admin = Depends(get_admin), db: Session = Depends(get_db)):
    if db.query(Empresa).filter(Empresa.cnpj == data.cnpj).first():
        raise HTTPException(status_code=400, detail="CNPJ já cadastrado")
    if db.query(Usuario).filter(Usuario.email == data.admin_email.lower()).first():
        raise HTTPException(status_code=400, detail="Email do admin da empresa já existe")
    empresa = Empresa(nome_fantasia=data.nome_fantasia, razao_social=data.razao_social, cnpj=data.cnpj, telefone=data.telefone, email=data.email, endereco=data.endereco, pix_chave=data.pix_chave, pix_nome=data.pix_nome or data.nome_fantasia, pix_cidade=data.pix_cidade or "MARINGA")
    db.add(empresa); db.flush()
    db.add(Usuario(empresa_id=empresa.id, nome=data.admin_nome, email=data.admin_email.lower(), senha_hash=hash_senha(data.admin_senha), papel=Role.admin_empresa.value))
    db.commit()
    for i in range(1, 11):
        db.add(Mesa(empresa_id=empresa.id, numero=f"{i:02d}", status=TableStatus.livre.value, total=0))
    db.commit()
    return {"mensagem": "Empresa criada com sucesso", "empresa_id": empresa.id, "login_admin_empresa": {"email": data.admin_email.lower(), "senha": data.admin_senha}}

@app.get("/empresa/me")
def empresa_me(usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    empresa = db.query(Empresa).filter(Empresa.id == usuario.empresa_id).first()
    return {"empresa_id": empresa.id, "nome_fantasia": empresa.nome_fantasia, "cnpj": empresa.cnpj, "usuario": {"nome": usuario.nome, "email": usuario.email, "papel": usuario.papel}}

@app.post("/empresa/usuarios")
def criar_usuario(data: UsuarioCreate, usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    if usuario.papel not in [Role.admin_empresa.value, Role.gerente.value]:
        raise HTTPException(status_code=403, detail="Sem permissão")
    db.add(Usuario(empresa_id=usuario.empresa_id, nome=data.nome, email=data.email.lower(), senha_hash=hash_senha(data.senha), papel=data.papel))
    db.commit()
    return {"mensagem": "Usuário criado"}

@app.post("/empresa/produtos")
def criar_produto(data: ProdutoCreate, usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    item = Produto(empresa_id=usuario.empresa_id, **data.dict()); db.add(item); db.commit(); db.refresh(item)
    return {"mensagem": "Produto criado", "produto_id": item.id}

@app.get("/empresa/produtos")
def listar_produtos(usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    itens = db.query(Produto).filter(Produto.empresa_id == usuario.empresa_id).order_by(Produto.id.desc()).all()
    return [{"id": p.id, "codigo": p.codigo, "nome": p.nome, "categoria": p.categoria, "preco": p.preco, "custo": p.custo, "estoque": p.estoque, "estoque_minimo": p.estoque_minimo, "unidade": p.unidade, "e_kg": p.e_kg, "estoque_baixo": p.estoque <= p.estoque_minimo} for p in itens]

@app.post("/empresa/clientes")
def criar_cliente(data: ClienteCreate, usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    item = Cliente(empresa_id=usuario.empresa_id, **data.dict()); db.add(item); db.commit(); db.refresh(item)
    return {"mensagem": "Cliente criado", "cliente_id": item.id}

@app.get("/empresa/clientes")
def listar_clientes(usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    itens = db.query(Cliente).filter(Cliente.empresa_id == usuario.empresa_id).order_by(Cliente.id.desc()).all()
    return [{"id": i.id, "nome": i.nome, "telefone": i.telefone, "email": i.email, "documento": i.documento, "endereco": i.endereco, "observacoes": i.observacoes} for i in itens]

@app.post("/empresa/fornecedores")
def criar_fornecedor(data: FornecedorCreate, usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    item = Fornecedor(empresa_id=usuario.empresa_id, **data.dict()); db.add(item); db.commit(); db.refresh(item)
    return {"mensagem": "Fornecedor criado", "fornecedor_id": item.id}

@app.get("/empresa/fornecedores")
def listar_fornecedores(usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    itens = db.query(Fornecedor).filter(Fornecedor.empresa_id == usuario.empresa_id).order_by(Fornecedor.id.desc()).all()
    return [{"id": i.id, "nome": i.nome, "telefone": i.telefone, "email": i.email, "documento": i.documento, "endereco": i.endereco} for i in itens]

@app.post("/empresa/funcionarios")
def criar_funcionario(data: FuncionarioCreate, usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    item = Funcionario(empresa_id=usuario.empresa_id, **data.dict()); db.add(item); db.commit(); db.refresh(item)
    return {"mensagem": "Funcionário criado", "funcionario_id": item.id}

@app.get("/empresa/funcionarios")
def listar_funcionarios(usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    itens = db.query(Funcionario).filter(Funcionario.empresa_id == usuario.empresa_id).order_by(Funcionario.id.desc()).all()
    return [{"id": i.id, "nome": i.nome, "cargo": i.cargo, "telefone": i.telefone, "email": i.email, "comissao_percentual": i.comissao_percentual} for i in itens]

@app.post("/empresa/ficha-tecnica")
def criar_ficha_tecnica(produto_id: int, ingrediente_id: int, quantidade: float, usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    ingrediente = db.query(Produto).filter(Produto.id == ingrediente_id, Produto.empresa_id == usuario.empresa_id).first()
    if not ingrediente:
        raise HTTPException(status_code=404, detail="Ingrediente não encontrado")
    item = FichaTecnica(empresa_id=usuario.empresa_id, produto_id=produto_id, ingrediente_id=ingrediente_id, quantidade=quantidade, custo_total=ingrediente.custo * quantidade)
    db.add(item); db.commit()
    return {"mensagem": "Ficha técnica adicionada", "custo_total": item.custo_total}

@app.get("/empresa/ficha-tecnica/{produto_id}")
def listar_ficha_tecnica(produto_id: int, usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    itens = db.query(FichaTecnica).filter(FichaTecnica.empresa_id == usuario.empresa_id, FichaTecnica.produto_id == produto_id).all()
    return {"produto_id": produto_id, "custo_total_prato": sum(i.custo_total for i in itens), "ingredientes": [{"ingrediente_id": i.ingrediente_id, "quantidade": i.quantidade, "custo_total": i.custo_total} for i in itens]}

@app.post("/empresa/mesas")
def abrir_mesa(data: MesaCreate, usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    mesa = Mesa(empresa_id=usuario.empresa_id, numero=data.numero, status=TableStatus.ocupada.value, cliente_nome=data.cliente_nome, total=0)
    db.add(mesa); db.commit(); db.refresh(mesa)
    return {"mensagem": "Mesa aberta", "mesa_id": mesa.id}

@app.get("/empresa/mesas")
def listar_mesas(usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    mesas = db.query(Mesa).filter(Mesa.empresa_id == usuario.empresa_id).order_by(Mesa.numero).all()
    return [{"id": m.id, "numero": m.numero, "status": m.status, "cliente_nome": m.cliente_nome, "total": m.total, "pix_code": m.pix_code} for m in mesas]

@app.post("/empresa/comandas")
def abrir_comanda(data: ComandaCreate, usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    item = Comanda(empresa_id=usuario.empresa_id, mesa_id=data.mesa_id, cliente_nome=data.cliente_nome, garcom_nome=data.garcom_nome, aberta=True, total=0)
    db.add(item); db.commit(); db.refresh(item)
    return {"mensagem": "Comanda aberta", "comanda_id": item.id}

@app.post("/empresa/pedidos")
def criar_pedido(data: PedidoCreate, usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    pedido = Pedido(empresa_id=usuario.empresa_id, comanda_id=data.comanda_id, mesa_id=data.mesa_id, origem=data.origem, status=OrderStatus.aberto.value, setor=data.setor, cliente_nome=data.cliente_nome, observacoes=data.observacoes, tempo_estimado_min=data.tempo_estimado_min)
    db.add(pedido); db.flush()
    total_pedido = 0
    for item in data.itens:
        produto = db.query(Produto).filter(Produto.id == item.produto_id, Produto.empresa_id == usuario.empresa_id).first()
        if not produto:
            raise HTTPException(status_code=404, detail="Produto não encontrado")
        if produto.estoque < item.quantidade:
            raise HTTPException(status_code=400, detail=f"Estoque insuficiente para {produto.nome}")
        subtotal = produto.preco * item.quantidade
        total_pedido += subtotal
        produto.estoque -= item.quantidade
        db.add(PedidoItem(pedido_id=pedido.id, produto_id=produto.id, nome=produto.nome, quantidade=item.quantidade, preco_unitario=produto.preco, subtotal=subtotal, observacoes=item.observacoes))
    if data.mesa_id:
        mesa = db.query(Mesa).filter(Mesa.id == data.mesa_id, Mesa.empresa_id == usuario.empresa_id).first()
        if mesa:
            mesa.status = TableStatus.ocupada.value
            mesa.total += total_pedido
            mesa.cliente_nome = data.cliente_nome or mesa.cliente_nome
            mesa.pix_code = empresa_pix(db, usuario.empresa_id, mesa.total)
    if data.comanda_id:
        comanda = db.query(Comanda).filter(Comanda.id == data.comanda_id, Comanda.empresa_id == usuario.empresa_id).first()
        if comanda:
            comanda.total += total_pedido
            comanda.cliente_nome = data.cliente_nome or comanda.cliente_nome
            comanda.garcom_nome = comanda.garcom_nome or usuario.nome
    db.commit(); db.refresh(pedido)
    return {"mensagem": "Pedido lançado", "pedido_id": pedido.id, "total": total_pedido}

@app.get("/empresa/pedidos")
def listar_pedidos(usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    pedidos = db.query(Pedido).filter(Pedido.empresa_id == usuario.empresa_id).order_by(Pedido.id.desc()).all()
    out = []
    for p in pedidos:
        atrasado = datetime.utcnow() > p.criado_em + timedelta(minutes=p.tempo_estimado_min) and p.status not in [OrderStatus.pronto.value, OrderStatus.entregue.value]
        out.append({"id": p.id, "origem": p.origem, "status": p.status, "setor": p.setor, "cliente_nome": p.cliente_nome, "criado_em": p.criado_em.isoformat(), "tempo_estimado_min": p.tempo_estimado_min, "semaforo": "atrasado" if atrasado else "pronto" if p.status == OrderStatus.pronto.value else "em preparo" if p.status == OrderStatus.preparando.value else "novo"})
    return out

@app.post("/empresa/pedidos/{pedido_id}/status")
def atualizar_status_pedido(pedido_id: int, status: str, usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    pedido = db.query(Pedido).filter(Pedido.id == pedido_id, Pedido.empresa_id == usuario.empresa_id).first()
    if not pedido:
        raise HTTPException(status_code=404, detail="Pedido não encontrado")
    pedido.status = status
    if status == OrderStatus.entregue.value:
        pedido.entregue_em = datetime.utcnow()
    db.commit()
    return {"mensagem": "Status atualizado", "status": status}

@app.get("/empresa/kds")
def tela_kds(usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    pedidos = db.query(Pedido).filter(Pedido.empresa_id == usuario.empresa_id, Pedido.status.in_([OrderStatus.aberto.value, OrderStatus.preparando.value, OrderStatus.pronto.value])).order_by(Pedido.criado_em.asc()).all()
    dados = []
    for p in pedidos:
        itens = db.query(PedidoItem).filter(PedidoItem.pedido_id == p.id).all()
        atrasado = datetime.utcnow() > p.criado_em + timedelta(minutes=p.tempo_estimado_min) and p.status != OrderStatus.pronto.value
        dados.append({"pedido_id": p.id, "setor": p.setor, "status": p.status, "cliente_nome": p.cliente_nome, "tempo_estimado_min": p.tempo_estimado_min, "criado_em": p.criado_em.isoformat(), "semaforo": "vermelho" if atrasado else "verde" if p.status == OrderStatus.pronto.value else "amarelo", "itens": [{"nome": i.nome, "quantidade": i.quantidade, "observacoes": i.observacoes} for i in itens]})
    return dados

@app.post("/empresa/caixa")
def movimento_caixa(data: CaixaCreate, usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    item = CaixaMovimento(empresa_id=usuario.empresa_id, tipo=data.tipo, descricao=data.descricao, valor=data.valor, usuario_nome=usuario.nome)
    db.add(item); db.commit()
    return {"mensagem": "Movimento de caixa registrado"}

@app.get("/empresa/caixa")
def listar_caixa(usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    itens = db.query(CaixaMovimento).filter(CaixaMovimento.empresa_id == usuario.empresa_id).order_by(CaixaMovimento.id.desc()).all()
    return [{"id": i.id, "tipo": i.tipo, "descricao": i.descricao, "valor": i.valor, "usuario_nome": i.usuario_nome, "criado_em": i.criado_em.isoformat()} for i in itens]

@app.post("/empresa/financeiro")
def criar_financeiro(data: FinanceiroCreate, usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    item = Financeiro(empresa_id=usuario.empresa_id, **data.dict()); db.add(item); db.commit(); db.refresh(item)
    return {"mensagem": "Lançamento financeiro criado", "financeiro_id": item.id}

@app.get("/empresa/financeiro")
def listar_financeiro(usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    itens = db.query(Financeiro).filter(Financeiro.empresa_id == usuario.empresa_id).order_by(Financeiro.id.desc()).all()
    return [{"id": i.id, "tipo": i.tipo, "descricao": i.descricao, "categoria": i.categoria, "valor": i.valor, "pago": i.pago, "vencimento": i.vencimento.isoformat() if i.vencimento else None} for i in itens]

@app.post("/empresa/delivery")
def criar_delivery(pedido_id: int, cliente_nome: str, endereco: str, entregador: str, usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    item = Delivery(empresa_id=usuario.empresa_id, pedido_id=pedido_id, cliente_nome=cliente_nome, endereco=endereco, entregador=entregador, status="aguardando", rota=f"Saída -> {endereco}")
    db.add(item); db.commit(); db.refresh(item)
    return {"mensagem": "Delivery criado", "delivery_id": item.id}

@app.get("/empresa/delivery")
def listar_delivery(usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    itens = db.query(Delivery).filter(Delivery.empresa_id == usuario.empresa_id).order_by(Delivery.id.desc()).all()
    return [{"id": i.id, "pedido_id": i.pedido_id, "cliente_nome": i.cliente_nome, "endereco": i.endereco, "entregador": i.entregador, "status": i.status, "rota": i.rota} for i in itens]

@app.post("/empresa/integracoes")
def salvar_integracao(tipo: str, ativo: bool, dados_json: str, usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    item = db.query(Integracao).filter(Integracao.empresa_id == usuario.empresa_id, Integracao.tipo == tipo.upper()).first()
    if not item:
        item = Integracao(empresa_id=usuario.empresa_id, tipo=tipo.upper())
        db.add(item)
    item.ativo = ativo
    item.dados_json = dados_json
    db.commit()
    return {"mensagem": f"Integração {tipo.upper()} salva"}

@app.get("/empresa/integracoes")
def listar_integracoes(usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    itens = db.query(Integracao).filter(Integracao.empresa_id == usuario.empresa_id).all()
    return [{"tipo": i.tipo, "ativo": i.ativo, "dados_json": i.dados_json} for i in itens]

@app.get("/empresa/relatorios/resumo")
def resumo(usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    produtos = db.query(Produto).filter(Produto.empresa_id == usuario.empresa_id).all()
    pedidos = db.query(Pedido).filter(Pedido.empresa_id == usuario.empresa_id).all()
    vendas_total = 0.0
    mais_vendidos = {}
    for p in pedidos:
        for i in db.query(PedidoItem).filter(PedidoItem.pedido_id == p.id).all():
            vendas_total += i.subtotal
            mais_vendidos[i.nome] = mais_vendidos.get(i.nome, 0) + i.quantidade
    ranking = sorted(mais_vendidos.items(), key=lambda x: x[1], reverse=True)[:10]
    return {"vendas_total": vendas_total, "qtd_produtos": len(produtos), "qtd_pedidos": len(pedidos), "produtos_mais_vendidos": ranking, "lucro_estimado": 0.0}

@app.get("/empresa/relatorios/garcons")
def desempenho_garcom(usuario = Depends(get_usuario), db: Session = Depends(get_db)):
    comandas = db.query(Comanda).filter(Comanda.empresa_id == usuario.empresa_id).all()
    dados = {}
    for c in comandas:
        nome = c.garcom_nome or "NÃO INFORMADO"
        dados[nome] = dados.get(nome, 0) + c.total
    return [{"garcom": nome, "total_vendido": total} for nome, total in dados.items()]

@app.get("/empresa/cardapio-digital")
def cardapio_digital(empresa_id: int, mesa: Optional[str] = None, db: Session = Depends(get_db)):
    produtos = db.query(Produto).filter(Produto.empresa_id == empresa_id, Produto.ativo == True).all()
    return {"empresa_id": empresa_id, "mesa": mesa, "produtos": [{"id": p.id, "nome": p.nome, "categoria": p.categoria, "preco": p.preco} for p in produtos]}

@app.post("/empresa/cardapio-digital/pedido")
def pedido_qr(empresa_id: int, mesa_id: Optional[int], cliente_nome: Optional[str], itens: List[PedidoItemCreate], db: Session = Depends(get_db)):
    pedido = Pedido(empresa_id=empresa_id, mesa_id=mesa_id, origem="QR", status=OrderStatus.aberto.value, setor="COZINHA", cliente_nome=cliente_nome, tempo_estimado_min=20)
    db.add(pedido); db.flush()
    total_pedido = 0.0
    for item in itens:
        produto = db.query(Produto).filter(Produto.id == item.produto_id, Produto.empresa_id == empresa_id).first()
        if not produto:
            raise HTTPException(status_code=404, detail="Produto não encontrado")
        subtotal = produto.preco * item.quantidade
        total_pedido += subtotal
        db.add(PedidoItem(pedido_id=pedido.id, produto_id=produto.id, nome=produto.nome, quantidade=item.quantidade, preco_unitario=produto.preco, subtotal=subtotal, observacoes=item.observacoes))
    if mesa_id:
        mesa = db.query(Mesa).filter(Mesa.id == mesa_id, Mesa.empresa_id == empresa_id).first()
        if mesa:
            mesa.total += total_pedido
            mesa.status = TableStatus.ocupada.value
            mesa.cliente_nome = cliente_nome or mesa.cliente_nome
            mesa.pix_code = empresa_pix(db, empresa_id, mesa.total)
    db.commit()
    return {"mensagem": "Pedido enviado pelo cardápio digital", "pedido_id": pedido.id}
